from pymongo import MongoClient
from bson.objectid import ObjectId

    
class AnimalShelter (object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30062
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
    
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)  # data should be dictionary
            if insert!=0:
                return True
            else:
                return False  
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
            
            # Complete this create method to implement the R in CRUD

    def read(self, data=None):
        if data is not None:
            search_data = self.database.animals.find(data,{"_id": False}) 
            #for doc in search_data:
            #    print(doc)
        else:
            search_data = self.database.animals.find({},{"_id": False})
        
        #return search_data
        #return list(search_data)
        return search_data
        
    # Create method to implement the U in CRUD.
    def update(self, initial, new):
        if initial is not None:
            if self.database.animals.count_documents(initial, limit = 1) != 0:
                update_result = self.database.animals.update_many(initial, {"$set": new})
                result_to_return = update_result.raw_result
            else:
                result_to_return = "Invalid - no document"
            return result_to_return
        else:
            raise Exception("Nothing to update, because data parameter is empty")

	# Create method to implement the D in CRUD.
    def delete(self, remove):
        if remove is not None:
            if self.database.animals.count_documents(remove, limit = 1) != 0:
                delete_result = self.database.animals.delete_many(remove)
                result = delete_result.raw_result
            else:
                result = "Invalid - no document"
            return result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
